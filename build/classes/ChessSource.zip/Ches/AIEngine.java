package Ches;

import java.util.LinkedList;

public class AIEngine {
	
    private Piece[][] board;	//actual game board
    private Piece[][][] AIBoard;//layers for keeping track of scores
    private int gameCounter;
    private King WKing;        //"counter" for White King
    private King BKing;        //"counter" for Black King
    LinkedList<Move> moves;
    public Move bestMove;
    public int bestScore = 0;
    private int position = 0; //0 if black is on top, else 1
    
    public AIEngine () {
        board = new Piece[8][8];
        initializeBoard();//actual game board gets updated by getBoard
        if (board[0][4].color == "BLACK")
            position = 0;
        else
            position = 1;
        moves = new LinkedList<Move>();
        this.generateMoves(board[1][0]);
        System.out.println("Moves:");
        System.out.println("Move (1,0)" +board[1][0].representation+ " can move to: " +
                moves.get(0).rowtwo + " " + moves.get(0).coltwo + " with score:" + moves.get(0).score);
    }
    
    //Creates the given piece on the local board for AI (not on AIBoard)
    public void createPiece(Piece p) {
        if (p.color == "WHITE"){
            switch (p.representation){
                case 'P':            
                    board[p.row][p.col] = new Pawn("WHITE", p.row, p.col);
                    ((Pawn)board[p.row][p.col]).enPassantAble = ((Pawn)p).enPassantAble;
                    break;
                case 'T':
                    board[p.row][p.col] = new Tower("WHITE", p.row, p.col);
                    break;
                case 'N':            
                    board[p.row][p.col] = new Knight("WHITE", p.row, p.col);
                    break;
                case 'B':            
                    board[p.row][p.col] = new Bishop("WHITE", p.row, p.col);
                    break;
                case 'Q':            
                    board[p.row][p.col] = new Queen("WHITE", p.row, p.col);
                    break;
                case 'K':            
                    board[p.row][p.col] = new King("WHITE", p.row, p.col);
                    break;
            }
        }
        else if (p.color == "BLACK"){
            switch (p.representation){
                case 'P':            
                    board[p.row][p.col] = new Pawn("BLACK", p.row, p.col);
                    ((Pawn)board[p.row][p.col]).enPassantAble = ((Pawn)p).enPassantAble;
                    break;
               case 'T':
                    board[p.row][p.col] = new Tower("BLACK", p.row, p.col);
                    break;
                case 'N':            
                    board[p.row][p.col] = new Knight("BLACK", p.row, p.col);
                    break;
                case 'B':            
                    board[p.row][p.col] = new Bishop("BLACK", p.row, p.col);
                    break;
                case 'Q':            
                    board[p.row][p.col] = new Queen("BLACK", p.row, p.col);
                    break;
                case 'K':            
                    board[p.row][p.col] = new King("BLACK", p.row, p.col);
                    break;
            }
        }
        else {
            board[p.row][p.col] = new Dull("NOCOLOR", p.row, p.col, ' ');
        }
    }
    
    //Puts the pieces on the board
    public void initializeBoard() {
        board[0][0] = new Tower("BLACK",0,0);
        board[0][1] = new Knight("BLACK",0,1);
        board[0][2] = new Bishop("BLACK",0,2);
	board[0][3] = new Queen("BLACK",0,3);
	board[0][4] = new King("BLACK",0,4);
	board[0][5] = new Bishop("BLACK",0,5);
	board[0][6] = new Knight("BLACK",0,6);
	board[0][7] = new Tower("BLACK",0,7);
	for (int i=0; i<8; i++) {
            board[1][i] = new Pawn("BLACK",1,i);
            board[6][i] = new Pawn("WHITE",6,i);
	}
	for (int i=0; i<8; i++) {
            for (int j=2; j<6; j++) {
                board[j][i] = new Dull("NOCOLOR",j,i,' ');
            }
	}
	board[7][0] = new Tower("WHITE",7,0);
	board[7][1] = new Knight("WHITE",7,1);
	board[7][2] = new Bishop("WHITE",7,2);
	board[7][3] = new Queen("WHITE",7,3);
	board[7][4] = new King("WHITE",7,4);
	board[7][5] = new Bishop("WHITE",7,5);
	board[7][6] = new Knight("WHITE",7,6);
	board[7][7] = new Tower("WHITE",7,7);
        
        WKing = (King)board[7][4];
        BKing = (King)board[0][4];
        
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
                board[i][j].moveCounter = 0;
    }

    //Updates the AIEngine's board	
    public void getBoard(Piece[][] bord){
        for (int i=0; i<8; i++){
            for (int j=0; j<8; j++){
                createPiece(bord[i][j]);
            }
        }
        //this.board = bord;
    }

    //gets the counter
    public void getGameCounter(int counter) {
        this.gameCounter = counter;
    }
    
    //Updates the kings situation
    public boolean getKing(King k){
        boolean result = true;
        
        if (k.color == "WHITE" && board[k.row][k.col].representation == 'K')
            WKing = (King)board[k.row][k.col];
        else if (k.color == "BLACK" && board[k.row][k.col].representation == 'K')
            BKing = (King)board[k.row][k.col];
        else{
            System.out.println("SOMETHING WRONG WITH GLOBAL KINGS");
            result = false;
        }
        return result;
    }
    
    //Prints whatever is in AIEngine's board
    public void printAIboard() {
        int k=0;
        System.out.println(" -----AI BOARD----");
        for (int i=0; i<8; i++){
            System.out.print(k);
            k++;
            for (int j=0; j<8; j++){
                System.out.print("|" + this.board[i][j].representation);
            }
            System.out.println("|");
            System.out.println(" -----------------");
        }
        System.out.println(" -0-1-2-3-4-5-6-7-");
        System.out.println("");
    }	

    //Starts the AI engine
    public Move StartAI() {
        Move m = new Move(0,0,0,0,0);
        
        for (int i=0; i<8; i++) {
            for (int j=0; j<8; j++) {
                for (int k=0; k<8; k++) {
                    for (int l=0; l<8; l++) {
                        if (board[i][j].canMove(k, l) && this.isMoveValid(board[i][j], board[k][l])>0){
                            m.rowone = i;
                            m.colone = j;
                            m.rowtwo = k;
                            m.coltwo = l;
                        }
                    }
                }
            }
        }
        
        return m;
    }
    
    //Checks if the made move is putting the King under Check
    public boolean isCreatingCheck(Piece p1, Piece p2){
        boolean result = false;
        
        updateBoard(board[p1.gRow()][p1.gCol()], board[p2.gRow()][p2.gCol()]);
        if (this.gameCounter % 2 == 1){
            if (this.isUnderAttack(WKing, WKing.getAttackingColor())>=0){
                System.out.println("IT IS CREATING check for white king!!!!!");
                result = true;
            }
        }
        else if (this.gameCounter % 2 == 0) {
            System.out.println("Is black king under attack? Creating check?");
            System.out.println("Black king row:"+BKing.row + " col:"+BKing.col);
            if (this.isUnderAttack(BKing, BKing.getAttackingColor())>=0){
                System.out.println("IT IS CREATING check for black king!!!!!");
                result = true;
            }
        }
        else {
            System.out.println("Something wrong with game counter in AI class: isCreatingCheck()");
        }
        strictUpdate(board[p2.gRow()][p2.gCol()], board[p1.gRow()][p1.gCol()]);
        System.out.println("IS CREATING CHECK IS RETURNING:"+result);
        return result;
    }
    
    //Checks if the made move is saving an existing king under check
    public boolean isStoppingCheck(Piece p1, Piece p2) {
        boolean result = true;
        
        //White's turn & white king is under attack
        if (this.gameCounter % 2 == 1 && (this.isUnderAttack(WKing, WKing.getAttackingColor())>=0)){
            updateBoard(board[p1.gRow()][p1.gCol()], board[p2.gRow()][p2.gCol()]);
            if (this.isUnderAttack(WKing, WKing.getAttackingColor())>=0)
                result = false;
            else
                result = true;
            strictUpdate(board[p2.gRow()][p2.gCol()], board[p1.gRow()][p1.gCol()]);
            System.out.println("after isStoppingCheck 2nd updateboard");
            this.printAIboard();
        }
        
        //Black's turn & black king is under attack
        if (this.gameCounter % 2 == 0 && (this.isUnderAttack(BKing, BKing.getAttackingColor())>=0)){
            updateBoard(board[p1.gRow()][p1.gCol()], board[p2.gRow()][p2.gCol()]);
            if (this.isUnderAttack(BKing, BKing.getAttackingColor())>=0){
                System.out.println("BKing is still under attack, it is not stopping check");
                result = false;
            }
            else
                result = true;
            
            strictUpdate(board[p2.gRow()][p2.gCol()], board[p1.gRow()][p1.gCol()]);
        }
        return result;
    }
    
    //Updates the board based on the game rules
    public void updateBoard(Piece p1, Piece p2) { 
        int row1=0, row2=0, col1=0, col2 = 0;
        row1 = p1.row;
        row2 = p2.row;
        col1 = p1.col;
        col2 = p2.col;
       
        if (p1.canMove(row2, col2) && this.isMoveValid(p1, p2)>0 &&
                this.goAllTheWay(p1, row2, col2)){
            System.out.println("Yes, updated the board");
            Piece temp = board[row1][col1];
            temp.Move(row2, col2);
            board[row2][col2] = temp;
            board[row1][col1] = new Dull("NOCOLOR", row1, col1, ' ');
            board[row2][col2].selected = false;
        }
    }
    
    //Does an update no matter what... only used to update back
    public void strictUpdate (Piece p1, Piece p2) {
        int row1=0, row2=0, col1=0, col2 = 0;
        row1 = p1.row;
        row2 = p2.row;
        col1 = p1.col;
        col2 = p2.col;
        
        if (p1.row != p2.row || p1.col != p2.col){
            Piece temp = board[row1][col1];
            temp.Move(row2, col2);
            temp.moveCounter = temp.moveCounter - 2;
            //temp.moveCounter--;
            board[row2][col2] = temp;
            board[row1][col1] = new Dull("NOCOLOR", row1, col1, ' ');
            board[row2][col2].selected = false;
        }
        
    }
    
    //Checks if the 2nd spot is occupied or can be attacked
    //This actually specifically checks for capturing moves
    public int isMoveValid(Piece p1, Piece p2) {
        //Pawns cannot capture straight
        if (p1.representation=='P' && p2.color != "NOCOLOR" && p1.color != p2.color && p1.col == p2.col){
            return 0;
        }
        //Pawn cannot move diagonal without capturing
        else if ((p1.representation=='P') && (p2.color.equals("NOCOLOR")) && (p1.col != p2.col)) {

            //En passant move by pawn (left)
            if (p1.col > 0 && p1.col < 7 && board[p1.gRow()][p1.gCol()-1].representation=='P' && board[p1.gRow()][p1.gCol()-1].getAttackingColor() == p1.color
                    && (p2.gCol() < p1.gCol()) && ((Pawn)board[p1.gRow()][p1.gCol()-1]).enPassantAble == true){
                return 3;
            }
            //En passant move by pawn (right)
            else if (p1.col > 0 && p1.col < 7 && board[p1.gRow()][p1.gCol()+1].representation=='P' && board[p1.gRow()][p1.gCol()+1].getAttackingColor() == p1.color
                    && (p2.gCol() > p1.gCol()) && ((Pawn)board[p1.gRow()][p1.gCol()+1]).enPassantAble == true){
                return 4;
            }
            //Pawn cannot move diagonal without capturing
            else {
                return 0;
            }
        }
        //And cannot move diagonal without capturing
        else if ((p1.representation=='P') && (p2.color == "NOCOLOR") && (p1.col != p2.col)){
            return 0;
        }
        //This is where the capture occurs and the function returns 2!!!
        else if (p2.color != p1.color){
            if (p2.color!="NOCOLOR"){
                    return 2;
            }
            return 1;
        }
        else {
            return 0;
        }
    }

    //Returns the score of a given move
    public int evaluate (int rowtwo, int coltwo) {
        int score = board[rowtwo][coltwo].value;
        
        return score;
    }
  
    //Checks if there is an enemy attack in the given direction for the given piece
    //attackingColor is the color which the piece is under attack by
    public int facingEnemy (int direction, Piece p, String attackingColor) {
        int i = p.row;
        int j = p.col;

        switch (direction) {

            case 0:	//Check north
                //Check for a knight attack
                if (i-2>=0 && j+1<=7 && board[i-2][j+1].representation=='N' && board[i-2][j+1].color == attackingColor){
                    return 0;
                }
                while (i>0){
                    i--;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR"){
                        return -1;
                    }
                    else if (board[i][j].color == "NOCOLOR"){
                        continue;
                    }
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00){
                            return 0;
                        }
                        else if (board[i][j].representation=='T' || board[i][j].representation=='Q'){
                            return 0;
                        }
                        else{
                            return -1;
                        }
                    }
                    else {
                        continue;
                    }
                }
                return -1;
            case 1: //Check north east
                //Check for a knight attack
                if (i-1>=0 && j+2<=7 && board[i-1][j+2].representation=='N' && board[i-1][j+2].color==attackingColor)
                    return 1;
                while (i>0 & j<7)	{
                    i--;
                    j++;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        if (board[i][j].representation=='P' && ((this.position==0 && board[i][j].color == "BLACK") ||
                                (this.position == 1 && board[i][j].color == "WHITE")) && board[i][j].getDistance(p)==1.00)
                            return 1;    
                        else if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 1;
                        else if (board[i][j].representation=='B' || board[i][j].representation=='Q')
                            return 1;
                        else
                            return -1;
                    }	
                    else {
                        continue;
                    }
                }
                return -1;
            case 2: //Check east
                //Check for a knight attack
                if (i+1<=7 && j+2<=7 && board[i+1][j+2].representation=='N' && board[i+1][j+2].color==attackingColor)
                    return 2;
                while (j<7){
                    j++;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                   else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 2;
                        else if (board[i][j].representation=='T' || board[i][j].representation=='Q')
                            return 2;
                        else
                            return -1;
                    }
                    else {
                        continue;
                    }
                }
                return -1;
            case 3: //Check south east
                //Check for a knight attack
                if (i+2<=7 && j+1<=7 && board[i+2][j+1].representation=='N' && board[i+2][j+1].color==attackingColor)
                    return 3;
                while (i<7 && j<7){
                    i++;
                    j++;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        if (board[i][j].representation=='P' && ((this.position==0 && board[i][j].color == "WHITE") ||
                                (this.position == 1 && board[i][j].color == "BLACK")) && board[i][j].getDistance(p)==1.00)
                            return 3;    
                        else if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 3;
                        else if (board[i][j].representation=='B' || board[i][j].representation=='Q')
                            return 3;
                        else
                            return -1;
                    }
                    else {
                        continue;
                    }
                }
                return -1;
            case 4: //Check south
                //Check for a knight attack
                if (i+2<=7 && j-1>=0 && board[i+2][j-1].representation=='N' && board[i+2][j-1].color==attackingColor)
                    return 4;
                while (i<7){
                    i++;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor)
                        if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 4;
                        else if (board[i][j].representation=='T' || board[i][j].representation=='Q')
                            return 4;
                        else
                            return -1;	
                    else {
                        continue;
                    }
                }
                return -1;
            case 5: //Check south west
                //Check for a knight attack
                System.out.println("Checking south west!");
                if (i+1<=7 && j-2>=0 && board[i+1][j-2].representation=='N' && board[i+1][j-2].color==attackingColor)
                    return 5;
                while (i<7 && j>0){
                    i++;
                    j--;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR"){
                        System.out.println("Ran into a friend, we're not under attack");
                        return -1;
                    }
                    else if (board[i][j].color == "NOCOLOR"){
                        System.out.println("NOCOLOR in the attack spot");
                        continue;
                    }
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        System.out.println("Attacking color matches the queen bug");
                        if (board[i][j].representation=='P' && ((this.position==0 && board[i][j].color == "WHITE") ||
                                (this.position == 1 && board[i][j].color == "BLACK")) && board[i][j].getDistance(p)==1.00){
                            System.out.println("here1");
                            return 5;
                        }
                        else if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00){
                            System.out.println("here2");
                            return 5;
                        }
                        else if (board[i][j].representation=='B' || board[i][j].representation=='Q'){
                            System.out.println("here3");
                            return 5;
                        }
                        else{
                            System.out.println("here4");
                            return -1;
                        }
                    }
                    else {
                        continue;
                    }
                }
                return -1;
            case 6: //Check west
                //Check for a knight attack
                if (i-1>=0 && j-2>=0 && board[i-1][j-2].representation=='N' && board[i-1][j-2].color==attackingColor)
                    return 6;
                while (j>0){
                    j--;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor)
                        if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 6;
                        else if (board[i][j].representation=='T' || board[i][j].representation=='Q')
                            return 6;
                        else
                            return -1;
                    else {
                        continue;
                    }
                }
                return -1;
            case 7: //Check north west
                //Check for a knight attack
                if (i-2>=0 && j-1>=0 && board[i-2][j-1].representation=='N' && board[i-2][j-1].color==attackingColor)
                    return 7;
                while (j>0 && i>0){
                    j--;
                    i--;
                    if (board[i][j].color == p.color && p.color != "NOCOLOR")
                        return -1;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != attackingColor) {
                        return -1;
                    }
                    else if (board[i][j].color == attackingColor){
                        if (board[i][j].representation=='P' && ((this.position==0 && board[i][j].color == "BLACK") ||
                                (this.position == 1 && board[i][j].color == "WHITE")) && board[i][j].getDistance(p)==1.00)
                            return 7;    
                        else if (board[i][j].representation=='K' && board[i][j].getDistance(p)==1.00)
                            return 7;
                        else if (board[i][j].representation=='B' || board[i][j].representation=='Q')
                            return 7;
                        else
                            return -1;
                    }
                    else {
                        continue;
                    }
                } 
                return -1;
            default:
                return 8;
        }     
    }    

    //Checks if the piece can run all the way to 2nd location
    public boolean goAllTheWay (Piece p1, int row2, int col2){
		
        int direction = 0;
        int i = p1.row;
        int j = p1.col;

        if (p1.representation == 'N')
                return true;

        direction = p1.getDirection(row2, col2);

        switch (direction) {
            case 0:	//Check north
                while (i!=row2 && i>=0){
                    i--;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && i!=row2)
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 1: //Check north east
                while ((i!=row2 & j!=col2) && i>=0 && j<8)	{
                    i--;
                    j++;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 2: //Check east
                while (j!=col2 && j<8){
                    j++;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && j!=col2)
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 3: //Check south east
                while ((i!=row2 & j!=col2) && i<8 && j<8){
                    i++;
                    j++;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
            case 4: //Check south
                while (i!=row2 && i<8){
                    i++;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && i!=row2)
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 5: //Check south west
                while ((i!=row2 & j!=col2) && i<8 && j>=0){
                    i++;
                    j--;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 6: //Check west
                while (j!=col2 && j>=0){
                    j--;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && (j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 7: //Check north west
                while ((i!=row2 & j!=col2) && j>=0 && i>=0){
                    j--;
                    i--;
                    if (board[i][j].color == p1.color)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != p1.color && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            default:
                return true;
            }
    }

    //Checks if there is nobody on the way of the given piece until row2,col2
    //Used for castling bug
    public boolean noOneOnTheWay (Piece p1, int row2, int col2){
          
        int direction = 0;
        int i = p1.row;
        int j = p1.col;

        if (p1.representation == 'N')
                return true;

        direction = p1.getDirection(row2, col2);

        switch (direction) {
            case 0:	//Check north
                while (i!=row2 && i>=0){
                    i--;
                    if (board[i][j].color == "NOCOLOR")
                        return true;
                    else if (board[i][j].color != "NOCOLOR" && i!=row2)
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else {
                        continue;
                    }
                }
                return true;
            case 1: //Check north east
                while ((i!=row2 & j!=col2) && i>=0 && j<8)	{
                    i--;
                    j++;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 2: //Check east
                while (j!=col2 && j<8){
                    j++;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && j!=col2)
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 3: //Check south east
                while ((i!=row2 & j!=col2) && i<8 && j<8){
                    i++;
                    j++;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
            case 4: //Check south
                while (i!=row2 && i<8){
                    i++;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && i!=row2)
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 5: //Check south west
                while ((i!=row2 & j!=col2) && i<8 && j>=0){
                    i++;
                    j--;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 6: //Check west
                while (j!=col2 && j>=0){
                    j--;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && (j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            case 7: //Check north west
                while ((i!=row2 & j!=col2) && j>=0 && i>=0){
                    j--;
                    i--;
                    if (board[i][j].color != "NOCOLOR")
                        return false;
                    else if (board[i][j].color == "NOCOLOR")
                        continue;
                    else if (board[i][j].color != "NOCOLOR" && (i!=row2 & j!=col2))
                        return false;	
                    else {
                        continue;
                    }
                }
                return true;
            default:
                return true;
            }
    }
    
    //Cheks if the given piece is under attack by the given AttackingColor
    public int isUnderAttack (Piece p, String AttackingColor){    
        int underAttack = -1;
        
        for (int i=0; i<8; i++){
            underAttack = facingEnemy(i, p, AttackingColor);
            if (underAttack >= 0)
                break;
        }
        return underAttack;
    }

    //Generates valid moves for the given piece
    public void generateMoves(Piece p1) {	
        
        Move currentMove = new Move(0,0,0,0,0);
        
        for (int i=0; i<8; i++){
            for (int j=0; j<8; j++){
                if (p1.canMove(i,j) && (this.isMoveValid(p1, board[i][j])> 0) &&
                        this.goAllTheWay(p1, i, j)){
                    currentMove.rowone = p1.gRow();
                    currentMove.rowtwo = i;
                    currentMove.colone = p1.gCol();
                    currentMove.coltwo = j;
                    currentMove.score = this.evaluate(i,j);
                    moves.add(currentMove);
                } 
            }
        }
    }
}