/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

/**
 *
 * @author Kaan
 */
public class Queen extends Piece {
    
    public Queen (String colour, int r, int c) {
        super.row = r;
        super.col = c;
        super.value = 70;
        super.representation = 'Q';
        super.color = colour;
    }
	
    public boolean canMove(int row2, int col2){
        if ((row2==row) && (col2==col)){
                return false;
        }
        else if ((row==row2)||(col==col2)){
                return true;	
        }
        else if ((Math.abs(row2-row))==(Math.abs(col2-col))){
                return true;
        }
        else {
                return false;
        }
    }
}
