
package Ches;

public class Pawn extends Piece {
	
    public int startingRow;
    public boolean enPassantAble;

    public Pawn (String color, int r, int c) {
       
        super.row = r;
        super.col = c;
        super.value = 10;
        super.representation = 'P';
        super.color = color;
        this.startingRow = r;
        this.enPassantAble = false;
        
    }
    
    public boolean canMove (int row2, int col2) {
    	if ((row2==row) && (col2==col)){
            return false;
	}
        
    	//two step forward by pawn at initial start
        else if(Math.abs(row-row2)==2 && col==col2 && this.moveCounter<=0){
            return true;
        }
        
        //regular move up by any pawn
        else if (((this.startingRow==1)&&((row2-row)==1)&&(col==col2))||((this.startingRow==6)&&((row-row2)==1)&&(col==col2))) {
            return true;
	}
		
	//attacking move by a pawn (doesn't check the enemy location if enemy exists or on whose team)
	else if((((row2-row)==1)&&(Math.abs(col-col2)==1)&&this.startingRow==1)||(((row-row2)==1)&&(Math.abs(col-col2)==1)&&this.startingRow==6)){
            return true;
	}
	else {
            return false;
	}
    }
}


/*Old else if for canMove
 //attacking move by a pawn (doesn't check the enemy location if enemy exists or on whose team)
 else if(((this.startingRow==1)&((row2-row)==1)&(Math.abs(col-col2)==1))||((this.startingRow==6)&((row-row2)==1)&(Math.abs(col-col2)==1))){
    return true;
 }
 
 */
