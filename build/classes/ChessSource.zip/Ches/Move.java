package Ches;

public class Move {
    public int rowone;
    public int colone;
    public int score;
    public int rowtwo;
    public int coltwo;
    
    public Move(int rowone, int colone, int score, int rowtwo, int coltwo) {
        this.rowone = rowone;
        this.colone = colone;
        this.score = score;
        this.rowtwo = rowtwo;
        this.coltwo = coltwo;
    }
      
}
