package Ches;

import java.net.*;
import java.io.*;

public class Server {
    
    public PrintWriter out;
    public BufferedReader in;
    public BufferedReader br;
    public Socket clientSocket = null;
    public ServerSocket serverSocket = null;
    
    
    public Server(String ip, int port) throws IOException {

        try {
            serverSocket = new ServerSocket(port);
        } catch (IOException e) {
            System.err.println("Could not listen on port: " + port + ".");
            System.exit(1);
        }
        System.out.println("over here1");

        try {
            clientSocket = serverSocket.accept();
        } catch (IOException e) {
            System.err.println("Accept failed.");
            System.exit(1);
        }
        System.out.println("over here2");
        out = new PrintWriter(clientSocket.getOutputStream(), true);
        in = new BufferedReader(
				new InputStreamReader(
				clientSocket.getInputStream()));
        br = new BufferedReader(new InputStreamReader(System.in));
        
        String inputLine, outputLine;
        //KnockKnockProtocol kkp = new KnockKnockProtocol();
        //outputLine = br.readLine();
        //inputLine = in.readLine();

        //outputLine = kkp.processInput(null);
        //out.println(outputLine);

        /*while ((inputLine = in.readLine()) != null) {
           //  outputLine = kkp.processInput(inputLine);
             out.println(outputLine);
             if (outputLine.equals("Bye."))
                break;
        }*/
        
    }


    public void closeServer() throws IOException {
        out.close();
        in.close();
        clientSocket.close();
        serverSocket.close();
    }

    public void sendData(String data) {
        out.println(data);
    }

    public String receiveData() throws IOException {
        String data;
        data = in.readLine();
        return data;
    }

}
