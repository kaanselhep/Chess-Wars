/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

/**
 *
 * @author Kaan
 */
public class Bishop extends Piece {
    
    public Bishop (String colour, int r, int c) {
        super.row = r;
        super.col = c;
        super.value = 30;
        super.representation = 'B';
        super.color = colour;
    }
	
    @Override
    public boolean canMove(int row2, int col2){
        if ((row2==row) && (col2==col)){
                return false;
        }
        else if ((Math.abs(row2-row))==(Math.abs(col2-col))){
                return true;
        }
        else{
                return false;	

        }
    }
}