/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author Kaan
 */
public class Promotion extends JFrame  {
    
    private Image cursorImage;
    private Image Logo;
    public char piece = 'Q';
    public ButtonGroup group;
    public JRadioButton queenButton;
    public JRadioButton knightButton;
    public JRadioButton rookButton;
    public JRadioButton bishopButton;
    public boolean shouldWait = true;
    public JButton okButton;
    
    public Promotion () {
        
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension dim = tk.getScreenSize();
        cursorImage = tk.getImage("images/chesswars2.gif");
        Point cursorHotSpot = new Point(0,0);
        Cursor customCursor = tk.createCustomCursor(cursorImage, cursorHotSpot, "Cursor");
        
        Image icon = Toolkit.getDefaultToolkit().getImage("images/nuke.jpg");
        this.setIconImage(icon);
        
        try{
            Logo = ImageIO.read(new File("images/ChessLogo.gif"));
        } catch (IOException ioe) {ioe.toString();}
        
        this.setLocation(((dim.width/2)-(350/2)), (dim.height/2)-(350/2));
        this.setCursor(customCursor);        
        this.setTitle("Chess Wars : Promote Pawn");
        this.setSize(315, 110);
        
        okButton = new JButton("OK");
        okButton.setMnemonic(KeyEvent.VK_ENTER);
        group = new ButtonGroup();
        JPanel panel = new JPanel();
        
        queenButton = new JRadioButton("Queen");
        queenButton.setActionCommand("Queen");
        queenButton.setMnemonic('q');
        queenButton.setSelected(true);
        knightButton = new JRadioButton("Knight");
        knightButton.setActionCommand("Knight");
        knightButton.setMnemonic('k');
        rookButton = new JRadioButton("Rook");
        rookButton.setActionCommand("Rook");
        rookButton.setMnemonic('r');
        bishopButton = new JRadioButton("Bishop");
        bishopButton.setActionCommand("Bishop");
        bishopButton.setMnemonic('b');

        this.getRootPane().setDefaultButton(okButton);
        
        group.add(queenButton);
        panel.add(queenButton);
        group.add(knightButton);
        panel.add(knightButton);
        group.add(rookButton);
        panel.add(rookButton);
        group.add(bishopButton);
        panel.add(bishopButton);
        
        panel.add(okButton);

        queenButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                piece = 'Q';
            }
        });
        rookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                piece = 'T';
            }
        });
        knightButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                piece = 'N';
            }
        });
        bishopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                piece = 'B';
            }
        });

        this.add(panel);
        this.setResizable(false);
        this.setVisible(false);
        
       okButton.addActionListener(new ActionListener() {
            public synchronized void actionPerformed(ActionEvent event){
                shouldWait = false;
                setVisible(false);
            }
        });
        
    }
    
    public char getPiece() {
        return this.piece;
    }
}
