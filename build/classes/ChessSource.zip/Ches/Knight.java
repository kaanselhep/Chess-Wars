/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

/**
 *
 * @author Kaan
 */
public class Knight extends Piece {
	
    public Knight (String colour, int r, int c)
    {
        super.row = r;
	super.col = c;
	super.value = 30;
	super.representation = 'N';
	super.color = colour;
    }

    @Override
    public int getDirection (int row2, int col2) {
         int direction = 0;
	
	//North
	if (this.row-row2==2 & col2-this.col==1)
            direction = 0;
	//North east
	else if (this.row-row2==1 & col2-this.col==2)
            direction = 1;
	//East
        else if (row2-this.row==1 & col2-this.col==2)
            direction = 2;
	//South east		
	else if (row2-this.row==2 & col2-this.col==1)
            direction = 3;	
	//South
	else if (row2-this.row==2 & this.col-col2==1)
            direction = 4;
	//South west
	else if (row2-this.row==1 & this.col-col2==2)
            direction = 5;
        //West
	else if (this.row-row2==1 & this.col-col2==2)
            direction = 6;
        //North west
        else if (this.row-row2==2 & this.col-col2==1)
            direction = 7;
        else {
            direction = -1;
        }
            	
        return direction;
    }
    
    public boolean canMove(int row2, int col2)  {
        if ((row2==row) && (col2==col)){
            return false;
        }
        else if (((Math.abs(row-row2)==2)&&(Math.abs(col-col2)==1))||((Math.abs(row-row2)==1)&&(Math.abs(col-col2)==2))){
            return true;
        }
        else{
		return false;
        }
    }
}
