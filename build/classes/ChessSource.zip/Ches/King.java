/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

/**
 *
 * @author Kaan
 */
public class King extends Piece {
    
    public boolean isCastling = false;

    public King (String colour, int r, int c){
	super.row = r;
	super.col = c;
	super.value = 500;
	super.representation = 'K';
	super.color = colour;
    }
   
    public boolean getCastling() {
        return this.isCastling;
    }
    
    public void setCastling(boolean castling) {
        this.isCastling = castling;
    }
    
    public boolean canMove (int row2, int col2) {
        
        if ((row2==row) && (col2==col)){
            return false;
        }
        else if ((this.moveCounter == 0) && (row==row2) && (Math.abs(col-col2)==2)){
            this.setCastling(true);
            return true;
        }
        else if (Math.abs(col-col2)<=1 && Math.abs(row-row2)<=1){
            return true;
        }
        else {
            return false;
        }
    }
}
