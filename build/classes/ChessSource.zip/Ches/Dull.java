/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Ches;

/**
 *
 * @author Kaan
 */
public class Dull extends Piece {
    
    public Dull (String color, int r, int c, char rep) {
        super.row = r;
        super.col = c;
        super.value = 5;
        super.representation = rep;
        super.color = color;
        super.moveCounter = 0;
    }
    
    public boolean canMove (int row2, int col2){
    	return false;
    }     
    
    public void Move(int row2, int col2) {
        super.Move(row2, col2);
    }
}
